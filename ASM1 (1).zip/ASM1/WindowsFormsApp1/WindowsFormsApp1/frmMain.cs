﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmMain : Form
    {
        private string vaiTro;

        public frmMain(string role)
        {
            InitializeComponent();
            vaiTro = role;
            PhanQuyen();
        }

        private void PhanQuyen()
        {
            if (vaiTro == "ThuThu")
            {
                quảnLýTàiKhoảnToolStripMenuItem.Enabled = false; // Chặn quản lý tài khoản
            }
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void quảnLýSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSach sachForm = new frmSach();
            sachForm.ShowDialog();
        }

        private void quảnLýTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTaiKhoan frm1 = new frmTaiKhoan();
            frm1.ShowDialog();
        }

        private void quảnLýĐộcGiảToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDocGia frm1 = new frmDocGia();
            frm1.ShowDialog();
        }

        private void quảnLýMượnTrảToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMuonTra frm1 = new frmMuonTra();
            frm1.ShowDialog();
        }

        private void báoCáoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBaoCao frm1 = new frmBaoCao();
            frm1.ShowDialog();
        }
    }
}
